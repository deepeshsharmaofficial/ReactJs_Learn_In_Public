### Debug the React app to correctly render the Card component with props.

Output:
<img src="https://res.cloudinary.com/dl26pbek4/image/upload/v1672730644/cn-questions/Capture_vccm5v.png">
