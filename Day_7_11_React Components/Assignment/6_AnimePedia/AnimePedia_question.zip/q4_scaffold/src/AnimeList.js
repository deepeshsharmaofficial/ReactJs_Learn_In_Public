import { Component } from "react";

// Complete the AnimeList Component
class AnimeList extends Component {
  render() {
    return <div className="anime-list"></div>;
  }
}

export default AnimeList;
