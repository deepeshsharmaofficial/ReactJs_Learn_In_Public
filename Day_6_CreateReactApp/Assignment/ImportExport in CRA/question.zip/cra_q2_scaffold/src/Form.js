// Complete the Form Component and export it

const Form = () => (
  <>
    <div>
      <form>{/* Create a h3, 2 inputs and 1 button here */}</form>
    </div>
  </>
);
