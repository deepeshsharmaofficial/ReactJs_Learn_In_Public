### Create a React App with external component files.

Objectives -

1. There are 2 external Components files <b>HomePage</b> and <b>Form</b> are given. You need to complete them and render Form Component in HomePage Component, and HomePage Component in App Component.

2. You need to take care that if login button is clicked, then form should not be submitted.

3. Craete and Export two variables <b>name</b> and <b>email</b> from the HomePage component and use them in Form as values for the respective inputs as shown in the image.

Output:
https://docs.google.com/document/d/1Y-CALiis0RWyGPbv81f2QO2jsyuEHQX2WALExn-lTiI/edit
